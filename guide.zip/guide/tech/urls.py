from tech import views
from django.urls import path
urlpatterns=[
path('guide/',views.guide,name="guide"),
path('gui/<str:name>',views.gui),
path('lapg/',views.lapg,name="lapg"),
path('ls/<str:name>',views.ls),
]