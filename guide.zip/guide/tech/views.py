from django.shortcuts import render,redirect
from django.http import HttpResponse

# Create your views here.



m=[{'name':'oneplus','storage':'2Gb','price':22000},
   {'name':'moto','storage':'16Gb','price':77000}]
mo={'dat':m}

l=[{'name':'access','storage':'2Tb','price':66000}]
lap={'data':l}

def guide(request):
    
    return render(request,'guide.html',mo)
def lapg(request):
    
    return render(request,'lapg.html',lap) 
def ls(request,name):
    lap={'data':l,'name':name}
    return render(request,'ls.html',lap)
def gui(request,name):
    mo={'dat':m,'name':name}
    return render(request,'ms.html',mo)